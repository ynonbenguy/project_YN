package geometries;
import java.util.ArrayList;
import java.util.Map;

import primitives.*;
public abstract class Geometry {
	
    protected  Color emission;
	
	//*functions*//
	public abstract Vector get_normal(Point3D p);
	//public abstract ArrayList<Point3D> findIntersections(Ray R);
	public abstract Map<Geometry,ArrayList<Point3D>> findIntersection(Ray y);
	public Color getEmission() {
		return emission;
	}
	public void setEmission(Color emission) {
		this.emission = emission;
	}
	
}
 
 //322981275
//314623364