package scene;
import java.util.ArrayList;


import primitives.*;
import elements.AmbientLight;
import elements.Camera;
import geometries.*;
public class Scene {
	private String NameScene;
	private Geometries listofgeom;
	private Camera camera;
	private double distence;
	private Color background;
	private AmbientLight ambientlight;
	
	
	//*constructors*//
	
	public Scene(String nameScene) {
		this.NameScene = nameScene;
		this.listofgeom=new Geometries();
		this.camera =null;
		this.distence = 0;
		this.background=new Color();
		this.ambientlight=new AmbientLight();
	}
	
	public Scene(String nameScene,Geometries list,Camera camera,double d,Color background, AmbientLight amb){
		this.NameScene=nameScene;
		this.listofgeom=list;
		this.camera=camera;
		this.distence=d;
		this.background=background;
		this.ambientlight=amb;
	}
	
	/*public Scene() {
		super();
		this.NameScene =null;
		this.listofgeom=new Geometries();
		this.camera =null;
		this.distence = 0;
		this.background=new AmbientLight();
	}*/
	
	
	
	
	//*getters and setters*//
	
	public Geometries getListofGeom() {
		return this.listofgeom;
	}
	public void setListofGeom(Geometries g) {
		this.listofgeom =g;
	}
	public Camera getCem() {
		return camera;
	}
	public void setCem(Camera cem) {
		this.camera = cem;
	}
	public double getDistence() {
		return distence;
	}
	public void setDistence(double distence) {
		this.distence = distence;
	}
	
	public Color getBackground(){
		return this.background;
	}
	public void setBackground(Color back){
		this.background=back;
	}
	
	public AmbientLight getAmbientlight()
	{
		return this.ambientlight;
	}
	
	public void setAmbientlight(AmbientLight amb)
	{
		this.ambientlight=amb;
	}
	//*function*//
	public void addGeometry(Geometry geomtry){
	 this.listofgeom.add(geomtry);
	}
}