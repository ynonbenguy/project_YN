package renderer;
import scene.*;


import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import primitives.*;
import geometries.*;

public class Render {
private Scene scene;
private ImageWriter imagewriter;




//*constructor*//

public Render(Scene scene, ImageWriter imagewriter) {
	this.scene = scene;
	this.imagewriter = imagewriter;
}

//*getters and setters*//

public Scene getScene() {
	return scene;
}

public void setScene(Scene scene) {
	this.scene = scene;
}

public ImageWriter getImagewriter() {
	return imagewriter;
}

public void setImagewriter(ImageWriter imagewriter) {
	this.imagewriter = imagewriter;
}

//*functions*//

public Map<Geometry,Point3D> getClosestPoint(Map<Geometry,ArrayList<Point3D>> intersectionPoints )
{
	Point3D point=new Point3D(intersectionPoints.get(getScene().getListofGeom()).get(0));
	double  min=point.distance(scene.getCem().getP0());
	ArrayList<Point3D> listofPoints= new ArrayList<Point3D>();
     for(Map.Entry<Geometry, ArrayList<Point3D>> el: intersectionPoints.entrySet())
	{
    	 for (int i=0; i<el.getValue().size();i++){
		 Point3D point2= new Point3D(el.getValue().get(i));
	    double d=(el.getValue().get(i)).distance(scene.getCem().getP0());
		if(d<min)
		{
			min=d;
			point=point2;
			listofPoints.add(point);
		}
		else{
			listofPoints.add(point);
		}
		}
	}
	return listofPoints;
}

public Color  calcColor(Geometry geometry,Point3D point)
{
	Color color =new Color(scene.getAmbientlight().getIntensity());
	color= color.add(geometry.getEmission());
	return  (color);
}


public void printGrid(int interval) // assuming that interval is between the lines of the grid
{
	for(int i=0;i<imagewriter.getWidth();i++)
	{
		for(int j=0;j<imagewriter.getHeight();j++)
		{
			if(i%interval==0||j%interval==0)
			{
				imagewriter.writePixel(i, j, 255,255,255);
			}
			else
			{
				imagewriter.writePixel(i, j, 0,0,0);
			}
		}
	}
}
public void renderImage()
{
	Ray ray=new Ray();
	Point3D ClosestPoint=new Point3D();
	for(int i=0;i<imagewriter.getNx();i++)
	{
		for(int j=0;j<imagewriter.getNy();j++)
		{
			ray=scene.getCem().construct_Ray_pixel(imagewriter.getNx(), imagewriter.getNy(), i, j, scene.getDistence(), imagewriter.getWidth(), imagewriter.getHeight());
			Map<Geometry, ArrayList<Point3D>> arr=scene.getListofGeom().findIntersections(ray);
			if(arr.isEmpty()==true)
			{
				imagewriter.writePixel(i, j,scene.getBackground());
			}
			else
			{
				Map<Geometry,Point3D> ClosestPoint1=getClosestPoint(arr);
				imagewriter.writePixel(i, j,calcColor(ClosestPoint1));
			}
		}
	}
}

}