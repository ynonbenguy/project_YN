package renderer;
import scene.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import primitives.*;
import geometries.*;

public class Render {
private Scene scene;
private ImageWriter imagewriter;




//*constructor*//

public Render(Scene scene, ImageWriter imagewriter) {
	this.scene = scene;
	this.imagewriter = imagewriter;
}

//*getters and setters*//

public Scene getScene() {
	return scene;
}

public void setScene(Scene scene) {
	this.scene = scene;
}

public ImageWriter getImagewriter() {
	return imagewriter;
}

public void setImagewriter(ImageWriter imagewriter) {
	this.imagewriter = imagewriter;
}

//*functions*//

public Map<Geometry,Point3D> getClosestPoint(Map<Geometry,ArrayList<Point3D>> intersectionPoints)
{
	double  min=Double.MAX_VALUE;
	Map<Geometry,Point3D> point=new HashMap<Geometry,Point3D>();
	for(Entry<Geometry, ArrayList<Point3D>> p: intersectionPoints.entrySet() )
	{
		Geometry key=p.getKey();
		ArrayList<Point3D> array=p.getValue();
		for(Point3D poit:array)
		{
			double d=poit.distance(scene.getCem().getP0());
			if(d<min)
			{
				min=d;
				point.clear();
				point.put(key, poit);
			}
		}
	}
	return point;
}
		


public Color  calcColor(Geometry geometry,Point3D point)
{
	Color color= scene.getAmbientlight().getIntensity();
	color.add(geometry.getEmission());
	return color;
}


public void printGrid(int interval) // assuming that interval is between the lines of the grid
{
	for(int i=0;i<imagewriter.getWidth();i++)
	{
		for(int j=0;j<imagewriter.getHeight();j++)
		{
			if(i%interval==0||j%interval==0)
			{
				imagewriter.writePixel(i, j, 255,255,255);
			}
			else
			{
				imagewriter.writePixel(i, j, 0,0,0);
			}
		}
	}
}
public void renderImage()
{
	Ray ray=new Ray();
	Map<Geometry,Point3D> ClosestPoint=new HashMap<Geometry,Point3D>();
	for(int i=0;i<imagewriter.getNx();i++)
	{
		for(int j=0;j<imagewriter.getNy();j++)
		{
			ray=scene.getCem().construct_Ray_pixel(imagewriter.getNx(), imagewriter.getNy(), i, j, scene.getDistence(), imagewriter.getWidth(), imagewriter.getHeight());
			Map<Geometry,ArrayList<Point3D>>  intersectionsPoints=new HashMap<Geometry,ArrayList<Point3D>> ();
			intersectionsPoints.putAll(scene.getListofGeom().findIntersections(ray));
			if(intersectionsPoints.isEmpty()==true)
			{
				imagewriter.writePixel(i, j,scene.getBackground());
			}
			else
			{
				Geometry geo=null;
				Point3D p=null;
				ClosestPoint.putAll(getClosestPoint(intersectionsPoints));
				for(Entry<Geometry,Point3D> s : ClosestPoint.entrySet()) {
					 geo =s.getKey();
					p =s.getValue();
				}
				imagewriter.writePixel(i, j,calcColor(geo,p));
			}
		}
	}
}

}