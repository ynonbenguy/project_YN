package geometries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import primitives.*;

public class Geometries extends Geometry {
		private ArrayList<Geometry> itsGeometries;
		
		public Geometries (){
			this.itsGeometries = new ArrayList<Geometry>();
		}
		public void add(Geometry g) {
			itsGeometries.add(g);
		}
		
		public Vector get_normal(Point3D point){
			return null;
		}
		
		public Map<Geometry,ArrayList<Point3D>> findIntersections(Ray R){
			Map<Geometry,ArrayList<Point3D>> listIntersection = new HashMap<Geometry,ArrayList<Point3D>>();
			/*for (int i = 0; i < itsGeometries.size(); i++) {
				listIntersection.addAll(itsGeometries.get(i).findIntersections(R));
			}*/
			for (Map.Entry<Geometry, ArrayList<Point3D>> el: listIntersection.entrySet()){
				Geometry geo =el.getKey();
				ArrayList<Point3D> P=el.getValue();
				Map<Geometry,ArrayList<Point3D>>  geometryIntersectionPoints= geo.findIntersection(R);
				if (P.isEmpty() ==false){
					listIntersection.values().add(P);
				}
			}
			return listIntersection;	
			}
		@Override
		public Map<Geometry, ArrayList<Point3D>> findIntersection(Ray y) {
			// TODO Auto-generated method stub
			return null;
		}
}

