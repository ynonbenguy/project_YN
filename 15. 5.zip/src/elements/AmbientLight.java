package elements;
import primitives.*;


public class AmbientLight {
private Color color;
private double k_a;
private Color intensity;


//*getters and setters*//
public Color getColor() {
	return color;
}

public void setColor(Color color) {
	this.color = color;
}

public double getK_a() {
	return k_a;
}

public void setK_a(double k_a) {
	this.k_a = k_a;
}

//*constructors*//

public AmbientLight(Color color,double k)
{
	this.color=color;
	this.k_a=k;
	intensity=new Color(this.color.scale(k));
}

public AmbientLight()
{
	this.color=new Color();
	k_a=0;
}

//get_intensity()
public Color getIntensity()
{
	return intensity;
}
}
