package unittests;
import geometries.*;
import elements.Camera;
import primitives.*;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class TriangleTest {

	@Test
	public void TriangleTest1() {
		final int Width = 3;
		final int Height = 3;
		Ray[][] rays = new Ray [Height][Width];
	    Camera camera = new Camera(new Point3D(0.0 ,0.0 ,0.0),
		new Vector (0.0, 1.0, 0.0),
		new Vector (0.0, 0.0, -1.0));
		Triangle triangle = new Triangle(new Point3D( 0, 1, -2),
		new Point3D( 1, -1, -2),
		new Point3D(-1, -1, -2),new Color(0,0,0));
		

		Map<Geometry,ArrayList<Point3D>> list_intersection1 = new HashMap<Geometry,ArrayList<Point3D>>();
		System.out.println("Camera:\n" + camera);
		for (int i = 0; i < Height; i++)
		{
		for (int j = 0; j < Width; j++)
		{
		rays[i][j] = camera.construct_Ray_pixel(Width, Height, j, i, 1, 3 * Width, 3 * Height);
		for(Map.Entry<Geometry,ArrayList<Point3D>> el:list_intersection1.entrySet() ){
			Map<Geometry,ArrayList<Point3D>> rayIntersectionPoints = triangle. findIntersections(rays[i][j]);
			ArrayList<Point3D> l=el.getValue();
			for (Point3D iPoint: l)
				l.add(iPoint);
			}
		}
		}
	for(Map.Entry<Geometry,ArrayList<Point3D>> el:list_intersection1.entrySet()){
		ArrayList<Point3D> l=el.getValue();
		assertTrue(l.size() == 1);
		System.out.println("Intersection Points:");
		for (Point3D iPoint: l)
		System.out.println(iPoint);
		System.out.println("--");
	}
}
	@Test
	public void TriangleTest2()
	{
		final int Width = 3;
		final int Height = 3;
		Ray[][] rays = new Ray [Height][Width];
	    Camera camera = new Camera(new Point3D(0.0 ,0.0 ,0.0),
		new Vector (0.0, 1.0, 0.0),
		new Vector (0.0, 0.0, -1.0));
	    Triangle triangle2 = new Triangle(new Point3D( 0, 10, -2),
	    		new Point3D( 1, -1, -2),
	    		new Point3D(-1, -1, -2),new Color(0,0,0));
	     Map<Geometry,ArrayList<Point3D>> list_intersection2 = new HashMap<Geometry,ArrayList<Point3D>>();
	    System.out.println("Camera:\n" + camera);
		for (int i = 0; i < Height; i++)
		{
		for (int j = 0; j < Width; j++)
		{
			for(Map.Entry<Geometry,ArrayList<Point3D>> el:list_intersection2.entrySet() ){
				Map<Geometry,ArrayList<Point3D>> rayIntersectionPoints = triangle2. findIntersections(rays[i][j]);
				ArrayList<Point3D> l=el.getValue();
				for (Point3D iPoint: l)
					l.add(iPoint);
				}
			}
			}
		for(Map.Entry<Geometry,ArrayList<Point3D>> el:list_intersection2.entrySet()){
			ArrayList<Point3D> l=el.getValue();
			assertTrue(l.size() == 1);
			System.out.println("Intersection Points:");
			for (Point3D iPoint: l)
			System.out.println(iPoint);
			System.out.println("--");
		}

	}
		
	}


