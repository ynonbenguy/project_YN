package unittests;

import static org.junit.Assert.*;

import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import primitives.*;
import geometries.*;
import elements.*;
import org.junit.Test;

public class PlaneTest {

	@Test
	public void testIntersectionPlane(){
		final int WIDTH = 3;
		final int HEIGHT = 3;
		Ray[][] rays = new Ray [HEIGHT][WIDTH];
		Camera camera = new Camera(new Point3D(0.0 ,0.0 ,0.0),
		 new Vector (0.0, 1.0, 0.0),
		 new Vector (0.0, 0.0, -1.0));
		Plane plane = new Plane(new Point3D(0.0, 0.0, -3.0),new Vector(0.0, 0.0, -1.0),new Color(0,0,0));
		Plane plane2 = new Plane(new Point3D(0.0, 0.0, -3.0),new Vector(0.0, 0.25, -1.0),new Color(0,0,0));
		Map<Geometry,ArrayList<Point3D>> intersectionPointsPlane = new HashMap<Geometry, ArrayList<Point3D>>();
		Map<Geometry,ArrayList<Point3D>> intersectionPointsPlane2 = new HashMap<Geometry,ArrayList<Point3D>>();
		System.out.println("Camera:\n" + camera);
		for (int i = 0; i < HEIGHT; i++){
		for (int j = 0; j < WIDTH; j++){
		rays[i][j] = camera.construct_Ray_pixel(
		WIDTH, HEIGHT, j, i, 1, 3 * WIDTH, 3 * HEIGHT);
		for (Map.Entry<Geometry,ArrayList<Point3D>> el:intersectionPointsPlane.entrySet())
		{
			Map<Geometry,ArrayList<Point3D>> rayIntersectionPoints = plane. findIntersections(rays[i][j]);
			ArrayList<Point3D> l=el.getValue();
			for (Point3D iPoint: l){
				intersectionPointsPlane.put(plane, l);

			}
		}
		for (Map.Entry<Geometry,ArrayList<Point3D>> el:intersectionPointsPlane2.entrySet())
		{
			Map<Geometry,ArrayList<Point3D>> rayIntersectionPoints = plane2. findIntersections(rays[i][j]);
			ArrayList<Point3D> l=el.getValue();
			for (Point3D iPoint: l){
				intersectionPointsPlane2.put(plane2, l);
			}
		}
		}
	    for (Map.Entry<Geometry,ArrayList<Point3D>> el:intersectionPointsPlane.entrySet())
		{
			ArrayList<Point3D> l1=el.getValue();
			for (Point3D iPoint: l1){
				assertTrue(intersectionPointsPlane. size() == 9);
		    System.out.println(iPoint);
			}
		}
	    for (Map.Entry<Geometry,ArrayList<Point3D>> el:intersectionPointsPlane2.entrySet())
			{
				ArrayList<Point3D> l1=el.getValue();
				for (Point3D iPoint: l1){
					assertTrue(intersectionPointsPlane2. size() == 9);
			        System.out.println(iPoint);
				}
			}
}
	}
}



