package geometries;

import java.util.ArrayList;

import primitives.*;

public class Geometries extends Geometry {
		private ArrayList itsGeometries = new ArrayList();
		public void add(Geometry g) {
			itsGeometries.add(g);
		}
		
		public Vector get_normal(Point3D point){
			return new Vector (new Point3D(0,0,0));
		}
		
		public ArrayList<Point3D> findIntersections(Ray R){
			ArrayList<Point3D> list_intersection=new ArrayList<Point3D>();
			return list_intersection;
		}
}

