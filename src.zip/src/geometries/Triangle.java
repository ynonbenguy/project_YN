package geometries;
import java.util.ArrayList;
import primitives.*;
public class Triangle extends Plane {
	private Point3D p2;
	private Point3D p3;
	public Vector get_normal (Point3D p){
		Vector V1=new Vector(p.vec_act(p2));
		Vector V2=new Vector(p.vec_act(p3));
		Vector V3=new Vector(V1.cross_product(V2));
		V3.normalization();
		return V3;
	}
	public Point3D getP2(){
		return p2;
	}
	public void setP2(Point3D p2){
		this.p2=p2;
	}
	public Point3D getP3(){
		return p3;
	}
	public void setP3(Point3D p3){
		this.p3=p3;
	}
	public Triangle (Point3D p1,Point3D p2,Point3D p3,Vector v){
		super(p1,v);
		this.p2=p2;
		this.p3=p3;
	}
	public Triangle (Point3D p1,Point3D p2,Point3D p3){
		super(p1,p2,p3);
		this.p2=p2;
		this.p3=p3;
	}// 3 points
	public Triangle()
	{
		super();
		p2=new Point3D(0,0,0);
		p3=new Point3D(0,0,0);
	}
	public ArrayList<Point3D> findIntersections(Ray R){
		ArrayList<Point3D> list_intersection=new ArrayList<Point3D>();
		list_intersection= findIntersections(R);
		
		Point3D P= new Point3D(list_intersection<Point3D>[0]);
		Vector v1= new Vector(p1.vec_act(p));
		Vector v2= new Vector(p2.vec_act(P));
		Vector v3= new Vector(p3.vec_act(P));
		Vector u1= new Vector(v1.cross_product(v2));
		Vector u2= new Vector(v2.cross_product(v3));
		Vector u3= new Vector(v3.croo_product(v1));
		Vector N1= new Vector(u1.normalization());
		Vector N2= new Vector(u2.normalization());
		Vector N3= new Vector(u3.normalization());
		Vector v= new Vector(p.vec_act(p0));
		double num1= v.dot_product(N1);
		double num2= v.dot_product(N2);
		double num3= v.dot_product(N3);
		if ((num1>0 && num2>0 && num>0)||(num1<0 && num2<0 && num3<0)){
			return list_intersections;
		}
		else {
			list_intersection.remove(R);
			return list_intersection;
		}
	}
}