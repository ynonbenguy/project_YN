package geometries;
import primitives.Ray;


public class Cylinder extends RadialGeometry {
	private double h;
	private Ray Direction;
	public Cylinder(double radious, double h, Ray direction) {
		super(radious);
		this.h = h;
		this.Direction = direction;
	}
	public Cylinder()
	{
		super();
		this.h=0;
		Direction=new Ray();
	}
	public double getH() {
		return h;
	}
	public void setH(double h) {
		this.h = h;
	}
	public Ray getDirection() {
		return Direction;
	}
	public void setDirection(Ray direction) {
		Direction = direction;
	}
	
}