package unittests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import primitives.*;
import geometries.*;

import org.junit.Test;

public class PlaneTest {

	@Test
	public void test_find_intersections() 
	{
		Point3D p0=new Point3D(0,0,0);
		Vector V_r=new Vector(0,1/Math.sqrt(2),-1/Math.sqrt(2));
		Ray R=new Ray(p0,V_r);
		Vector N=new Vector(-2,1,1/2);
		Point3D poin=new Point3D(-1,1,-2);
		Plane pl=new Plane(poin,N);
		ArrayList<Point3D > L=new ArrayList<Point3D>();
		L=pl.findIntersections(R);
		Point3D p_n=new Point3D(0,3.5,-3.5);
		assertEquals(p_n,L.get(0));

		
		
	}

}
