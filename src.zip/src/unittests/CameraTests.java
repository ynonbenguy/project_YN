package unittests;

import static org.junit.Assert.*;

import org.junit.Test;
import primitives.*;
import elements.*;
public class CameraTests {

	@Test
	public void test_construction_ray1() {
		int Nx=3;
		int Ny=3;
		int i=2;
		int j=1;
		double screenDistance=4;
		double screenWidth=5;
		double screenHeight=3;
		Point3D p0=new Point3D(0,0,0);
		Vector Vto=new Vector(0,0,-1);
		Vector Vup=new Vector(0,-1,0);
		//Vector Vright=new Vector(-1,0,0);
		Camera camer=new Camera(p0,Vup,Vto);
		Vector Pij=new Vector(camer.construct_Ray_pixel( Nx,Ny, i, j,screenDistance, screenWidth,screenHeight));
		Vector Pijtest=new Vector(0,0,-4);
		assertEquals (Pij,Pijtest);
	}
	@Test
	public void test_construction_ray2() {
		int Nx=4;
		int Ny=4;
		int i=3;
		int j=3;
		double screenDistance=5;
		double screenWidth=5;
		double screenHeight=3;
		Point3D p0=new Point3D(0,0,0);
		Vector Vto=new Vector(0,0,-1);
		Vector Vup=new Vector(0,-1,0);
		//Vector Vright=new Vector(-1,0,0);
		Camera camer=new Camera(p0,Vup,Vto);
		Vector Pij=new Vector(camer.construct_Ray_pixel( Nx,Ny, i, j,screenDistance, screenWidth,screenHeight));
		Vector Pijtest=new Vector(-0.375,0.625,-5.0);
		assertEquals (Pij,Pijtest);

}
}
