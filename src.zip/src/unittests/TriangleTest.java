package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

public class TriangleTest {

	@Test
	public void TriangleTest() {
		
	}

}
