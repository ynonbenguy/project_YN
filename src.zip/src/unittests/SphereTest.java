package unittests;
import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import primitives.*;
import geometries.*;


public class SphereTest {
	@Test
	public void Spheretest() {
		Point3D p0=new Point3D(0,0,0);
		Vector V_r=new Vector(0,1/Math.sqrt(2),-1/Math.sqrt(2));
		Ray R=new Ray(p0,V_r);
		double redious=2.0;
		Point3D O= new Point3D(2,3,2);
		Ray R1= new Ray(R.findIntersections());
		
	}

}
