package scene;
import java.util.ArrayList;
import primitives.*;
import elements.Camera;
import geometries.*;
public class Scene {
	String NameScene;
	private ArrayList<Geometry> otherArray;
	private Camera camera;
	double distence;
	public Scene(String nameScene) {
		super();
		NameScene = nameScene;
	}
	
	public Scene() {
		super();
		this.NameScene = "";
		this.otherArray =null;
		this.camera =null;
		this.distence = 0;
	}
	
	public ArrayList<Geometry> getOtherArray() {
		return otherArray;
	}
	public void setOtherArray(ArrayList<Geometry> otherArray) {
		this.otherArray = otherArray;
	}
	public Camera getCem() {
		return camera;
	}
	public void setCem(Camera cem) {
		this.camera = camera;
	}
	public double getDistence() {
		return distence;
	}
	public void setDistence(double distence) {
		this.distence = distence;
	}
	public ArrayList<Geometry> addGeometry(Geometry geomtry){
	 otherArray.add(geomtry);
	 return otherArray;	
	}
}