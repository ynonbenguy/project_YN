package elements;
import primitives.*;
public class Camera {
private Point3D p0;
private Vector Vup;
private Vector Vto;
private Vector Vright;
	public  Camera (Point3D p,Vector Vu ,Vector Vt) /*throws Exception*/
	{
	p0=new Point3D(p.getX(),p.getY(),p.getZ());
	Vup=new Vector(Vu);
	Vto=new Vector(Vt);
	/*double x=(Vu.dot_product(Vt));
	double y=(Vu.length_vec())*(Vt.length_vec());
	double z=x/y;
		if(z!=0.0)
		{
			throw new Exception("Error");
		}
		*/
	Vright=new Vector(Vu.cross_product(Vt));
	}
	public  Vector construct_Ray_pixel(int Nx, int Ny, int i,int j,double screenDistance,double screenWidth,double screenHeight){
	  double Ry=screenHeight/Ny;
	  double Rx=screenWidth/Nx;
	  Vector v=new Vector(this.Vto.scalar(screenDistance));
	  Point3D Pc=new Point3D(p0.add_vector(v));
	  double Yj=(j-(Ny/2))*Ry-(Ry/2);
	  double Xi=(i-(Nx/2))*Rx-(Rx/2);
	  Vector XiVright=new Vector (this.Vright.scalar(Xi));
	  Vector YjVup=new Vector (this.Vup.scalar(Yj));
	  Vector essVector=new Vector(XiVright.sub_vector(YjVup));
	  Vector Pij=new Vector(Pc.add_vector(essVector));
	  Pij.normalization();
	  return Pij;
	}
}