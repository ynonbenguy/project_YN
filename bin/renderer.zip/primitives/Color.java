package primitives;

public class Color {
	java.awt.Color _color;
	float red;
	float blue;
	float green;
	/***** gterrs settees*****/
	public java.awt.Color get_color() {
		return _color;
	}
	public void set_color(java.awt.Color _color) {
		this._color = _color;
	}
	public float getRed() {
		return red;
	}
	public void setRed(float red) {
		this.red = red;
	}
	public float getBlue() {
		return blue;
	}
	public void setBlue(float blue) {
		this.blue = blue;
	}
	public float getGreen() {
		return green;
	}
	public void setGreen(float green) {
		this.green = green;
	}
	public java.awt.Color add(java.awt.Color _color){

		return _color;
	}
	public void  scale(double n){
		red *= n;
	    blue *= n;
	    green *= n;
			}
	public void reduce(double n){
		red /= n;
		blue /=n;
		green /=n;
	}
	
}
