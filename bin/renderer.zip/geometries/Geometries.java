package geometries;

import java.util.ArrayList;

import primitives.*;

public class Geometries extends Geometry {
		private ArrayList<Geometry> itsGeometries;
		
		public Geometries (){
			this.itsGeometries = new ArrayList<Geometry>();
		}
		public void add(Geometry g) {
			itsGeometries.add(g);
		}
		
		public Vector get_normal(Point3D point){
			return null;
		}
		
		public ArrayList<Point3D> findIntersections(Ray R){
			ArrayList<Point3D> listIntersection = new ArrayList<Point3D>();
			for (int i = 0; i < itsGeometries.size(); i++) {
				listIntersection.addAll(itsGeometries.get(i).findIntersections(R));
			}
			return listIntersection;	
			}
}

