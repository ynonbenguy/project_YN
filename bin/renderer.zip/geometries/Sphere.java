package geometries;
import java.util.ArrayList;
import primitives.*;
public class Sphere extends RadialGeometry {
	private  Point3D p;
	public Vector get_normal(Point3D p0)
	{
	  Vector v=new Vector(this.p.vec_act(p0));
	  v.normalization();
	  return v;
	}
	public Sphere(double radious, Point3D p) {
		super(radious);
		this.p = p;
	}
	public Sphere()
	{
		super();
		p=new Point3D(0,0,0);
	}
	public Point3D getP() {
		return p;
	}
	public void setP(Point3D p) {
		this.p = p;
	}
	public void setP(double x,double y,double z)
	{
		this.p.setX(x);
		this.p.setY(y);
		this.p.setZ(z);
	}
	public ArrayList<Point3D> findIntersections(Ray R){
		ArrayList<Point3D> list_intersection=new ArrayList<Point3D>();
		Vector u=new Vector(R.getP00().vec_act(this.p));
		double Tm=(R.getDirection()).dot_product(u);
		double ul=u.length_vec();
		double d=Math.sqrt(Math.pow(ul,2)-Math.pow(Tm, 2));
		if(d>getRadious()){
			list_intersection.add(null);
			return list_intersection;
		}
		double Th=Math.sqrt(Math.pow(getRadious(), 2)-Math.pow(d, 2));
		double t1=Tm+Th;
		Vector k1= new Vector(R.getDirection().scalar(t1));
		Point3D P1=new Point3D (R.getP00().add_vector(k1));
		list_intersection.add(P1);
		double t2=Tm-Th;
		Vector k2= new Vector(R.getDirection().scalar(t2));
		Point3D p2 = new Point3D (R.getP00().add_vector(k2));
		list_intersection.add(p2);
		return list_intersection;
	}
}