package geometries;
import primitives.Vector;
import primitives.Point3D;

public abstract class Geometry {
public abstract Vector get_normal(Point3D p);
}
