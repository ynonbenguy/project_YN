package geometries;
import primitives.Ray;

import java.util.jar.Pack200;

import primitives.Point3D;
import primitives.Vector;
public class Cylinder extends RadialGeometry {
	private double h;
	private Ray Direction;
	public Vector get_normal(Point3D p)
	{
		double dis1= sqr(p.getX()-Ray.getX())+sqr(p.getY()-Ray.getY())+sqr(p.getZ()-Ray.getZ());
		double dis=Math.rint(dis1);
		int num=new Math.root(sqr(dis)+sqr(this.h));
		Vector v=new Vector(Ray.scalar(num));
		Vector Normal=new Vectorr (just go up);
		
	}
	public Cylinder(double radious, double h, Ray direction) {
		super(radious);
		this.h = h;
		this.Direction = direction;
	}
	public Cylinder()
	{
		super();
		this.h=0;
		Direction=new Ray();
	}
	public double getH() {
		return h;
	}
	public void setH(double h) {
		this.h = h;
	}
	public Ray getDirection() {
		return Direction;
	}
	public void setDirection(Ray direction) {
		Direction = direction;
	}
	
}