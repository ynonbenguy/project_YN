package geometries;

public class RadialGeometry {
	private double radious;

	public RadialGeometry(double radious) {
		this.radious = radious;
	}
	public RadialGeometry()
	{
		this.radious=0;
	}
	public RadialGeometry(RadialGeometry R)
	{
		this.radious=R.getRadious();
	}
	public double getRadious() {
		return this.radious;
	}
	public void setRadious(double radious) {
		this.radious = radious;
	}
}
