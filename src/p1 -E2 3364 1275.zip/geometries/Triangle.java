package geometries;
import primitives.Point3D;
import primitives.Vector;
public class Triangle extends Plane {
	private Point3D p2;
	private Point3D p3;
	public Vector get_normal (Point3D p){
		return null;
	}
	public Point3D getP2(){
		return p2;
	}
	public void setP2(Point3D p2){
		this.p2=p2;
	}
	public Point3D getP3(){
		return p3;
	}
	public void setP3(Point3D p3){
		this.p3=p3;
	}
	public Triangle (Point3D p1,Point3D p2,Point3D p3,Vector v){
		super(p1,v);
		this.p2=p2;
		this.p3=p3;
	}
	public Triangle (Point3D p1,Point3D p2,Point3D p3){
		super(p1,p2,p3);
		this.p2=p2;
		this.p3=p3;
	}// 3 points
	public Triangle()
	{
		super();
		p2=new Point3D(0,0,0);
		p3=new Point3D(0,0,0);
	}
	
}