package geometries;
import primitives.Point3D;
import primitives.Vector;
public class Sphere extends RadialGeometry {
	private  Point3D p;
	public Vector get_normal(Point3D p0)
	{
	  Vector v=new Vector(this.p.vec_act(p0));
	  v.normalization();
	  return v;
	}
	public Sphere(double radious, Point3D p) {
		super(radious);
		this.p = p;
	}
	public Sphere()
	{
		super();
		p=new Point3D(0,0,0);
	}
	public Point3D getP() {
		return p;
	}
	public void setP(Point3D p) {
		this.p = p;
	}
	public void setP(double x,double y,double z)
	{
		this.p.setX(x);
		this.p.setY(y);
		this.p.setZ(z);
	}
	
}