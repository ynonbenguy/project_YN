package geometries;

import java.util.ArrayList;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public abstract class RadialGeometry extends Geometry{
	private double radious;

	public RadialGeometry(double radious) {
		this.radious = radious;
	}
	public RadialGeometry()
	{
		this.radious=0;
	}
	public RadialGeometry(RadialGeometry R)
	{
		this.radious=R.getRadious();
	}
	public double getRadious() {
		return this.radious;
	}
	public void setRadious(double radious) {
		this.radious = radious;
	}
	@Override
	public Vector get_normal(Point3D p) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<Point3D> findIntersections(Ray R) {
		// TODO Auto-generated method stub
		return null;
	}
}

