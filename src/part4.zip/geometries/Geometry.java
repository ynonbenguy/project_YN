package geometries;
import java.util.ArrayList;
import primitives.*;
public abstract class Geometry {
	public abstract Vector get_normal(Point3D p);
	public abstract ArrayList<Point3D> findIntersections(Ray R);
}
 
 //322981275
//314623364