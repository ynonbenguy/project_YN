package primitives;

public class Color {
     private int rgb;
     public Color(int rgb) {
	     this.rgb = rgb;
     }
     public Color(int r,int j,int b){
	    this.rgb=r*100+j*10+b;
     }
     public Color(Color cor){
	    this.rgb=cor.getColor();
     }
     public Color(){
	    this.rgb=0;
     }
     public Color  add (int rgb){
	    int rgbN=this.rgb+=rgb;
	    return new Color(rgbN);
     }
     public Color scale(double d){
	    int rgbN=this.rgb*=d;
	    return new Color(rgbN);
     }
     public Color reduce(double d){
	    int rgbN=this.rgb/=d;
	    return new Color(rgbN);
     }
     public int getColor(){
	 return rgb;
     }
}


