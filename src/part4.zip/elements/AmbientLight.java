package elements;
import primitives.Color;


public class AmbientLight {
Color color;
double k_a;
public Color getColor(Color color){
	return color;
}
public Color getIntensity()
{
	return (this.color.scale(k_a));
}
}
