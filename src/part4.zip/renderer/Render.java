package renderer;
import scene.*;

import java.awt.List;
import java.util.ArrayList;
import primitives.*;
import elements.*;
import geometries.*;
public class Render {
private Scene scene;
private ImageWriter imagewriter;


public Render(ImageWriter imageWriter, Scene scene) {
	this.imagewriter=imagewriter;
	this.scene=scene;
}

public Point3D getClosestPoint(ArrayList<Point3D> arr )
{
	double  min=arr.get(0).distance(scene.getCem().getP0());
	Point3D point=arr.get(0);
	for(int i=1;i<arr.size();i++)
	{
		double d=arr.get(i).distance(scene.getCem().getP0());
		if(d<min)
		{
			min=d;
			point=arr.get(i);
		}
	}
	return point;
}

public Color  calcColor(Point3D point)
{
	return  (scene.getColor().getIntensity());
}


public void printGrid(int interval) // assuming that interval is between the lines of the grid
{
	for(int i=0;i<imagewriter.getWidth();i++)
	{
		for(int j=0;j<imagewriter.getHeight();j++)
		{
			if(i%interval==0||j%interval==0)
			{
				imagewriter.writePixel(i, j, 1,2,7);
			}
			else
			{
				imagewriter.writePixel(i, j, 0,0,0);
			}
		}
	}
}
public void RenderImage(){
	int l=0;
	for (int i=0; i< imagewriter.getNx(); i++){
		for (int j=0; j<imagewriter.getNy() ; j++)
		{
			Ray ray=new Ray(scene.getCem().construct_Ray_pixel(imagewriter.getNx(), imagewriter.getNy(), i, j, scene.getDistence(), imagewriter.getWidth(), imagewriter.getHeight()));
			ArrayList<Point3D>intersectionPoints=scene.getOtherArray().get(l).findIntersections(ray);
			l=+1;
			if(intersectionPoints==null){
				imagewriter.writePixel(i, j,scene.getColor().getColor());
			}
			else 
			{
				Point3D closesPoint=new Point3D(getClosestPoint(intersectionPoints));
				imagewriter.writePixel(i, j, calcColor(closesPoint));
			}
		}
	}
	
}


}
