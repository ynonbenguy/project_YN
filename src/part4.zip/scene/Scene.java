package scene;
import java.util.ArrayList;

import primitives.*;
import elements.AmbientLight;
import elements.Camera;
import geometries.*;
public class Scene {
	private String NameScene;
	private ArrayList<Geometry> otherArray;
	private Camera camera;
	private double distence;
	private AmbientLight color;
	public Scene(String nameScene) {
		this.NameScene = nameScene;
		this.otherArray =null;
		this.camera =null;
		this.distence = 0;
		this.color=null;
	}
	
	public Scene() {
		super();
		this.NameScene =null;
		this.otherArray =null;
		this.camera =null;
		this.distence = 0;
		this.color=null;
	}
	
	public ArrayList<Geometry> getOtherArray() {
		return otherArray;
	}
	public void setOtherArray(ArrayList<Geometry> otherArray) {
		this.otherArray = otherArray;
	}
	public Camera getCem() {
		return camera;
	}
	public void setCem(Camera cem) {
		this.camera = cem;
	}
	public double getDistence() {
		return distence;
	}
	public void setDistence(double distence) {
		this.distence = distence;
	}
	
	public AmbientLight getColor(){
		return color;
	}
	public void setColor(AmbientLight color){
		this.color=color;
	}
	public ArrayList<Geometry> addGeometry(Geometry geomtry){
	 otherArray.add(geomtry);
	 return otherArray;	
	}
}